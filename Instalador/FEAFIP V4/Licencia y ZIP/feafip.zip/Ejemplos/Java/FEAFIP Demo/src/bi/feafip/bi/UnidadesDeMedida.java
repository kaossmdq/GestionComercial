package feafip.bi  ;

import com4j.*;

/**
 */
public enum UnidadesDeMedida {
  /**
   * <p>
   * The value of this constant is 0
   * </p>
   */
  const0, // 0
  /**
   * <p>
   * The value of this constant is 1
   * </p>
   */
  Const1, // 1
}
